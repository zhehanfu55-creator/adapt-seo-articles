# Editorial standards from the user's prior directions

These are writing preferences, not policies issued by any publication. Apply them to the source article before platform adaptation. A later user instruction takes priority.

## Reader and argument

- Open with an actual reader task: who does what, in which setting, under what constraint, and what answer they need. Favor field operators, device developers, integration teams, technical purchasers, and partners with a concrete job over a generic “IoT audience.”
- A professional grower already knows temperature matters. Explain which observation changes a decision, how to interpret it, where the station/sensor should be deployed, and what limitations remain. Similarly, an engineering buyer often knows the product category; do not make them follow an invented selection tree unless the article actually helps their work.
- Keep one technical subject coherent. For a radar-rainfall article, answer rain-measurement questions for a specific role and setting before discussing an unrelated connectivity architecture. For wireless links, separate PHY capability, protocol stack, network setup, and end-product readiness.
- Anchor claims to operational choices: measurement quality, installation/service work, integration requirements, validation, purchasing due diligence. Do not recite feature lists and call them benefits. Include limitations when they affect the decision.

## Claims and product references

- Verify technical details against official datasheets, product documentation, the relevant standard/regulator, or a documented test. Quote a source or state the conditions for numbers such as sensitivity, range, rain resolution, IP rating, accuracy, battery life, duty cycle, or throughput.
- Report field test results with band, configuration, power, antenna, environment, sample size or route, measurement method, and date when relevant. A prototype or community demo proves an integration path under its actual conditions, not a production rollout or guaranteed performance.
- Distinguish specification from inference and confirmed deployment from illustrative scenario. Do not assert certifications, distributor listing, order numbers, stock, regional legality, or recent launches from memory.
- Mention Seeed Studio affiliation truthfully when writing under an employee byline or discussing company products. Do not pretend personal field testing, anonymous independent review, customer consent, or editorial endorsement.
- Incorporate Wio or SenseCAP products only when they answer a real constraint. Avoid making an internal article a head-to-head that dismisses another Seeed product. Explain scope and limits rather than declaring universal winners. For DigiKey product references, use a verified official DigiKey part/order number if one exists; otherwise omit the order number and any suggestion that DigiKey sells it.
- Linking: include the author's relevant landing-page URL once in each guest article body, with natural anchor text and a reason a reader might visit it. The source article, its canonical URL, and the landing page serve different purposes. For this user's module articles, select https://www.seeedstudio.com/wio-module; for professional weather-station articles, select https://www.seeedstudio.com/page/sensecap-professional-weather-station. If the target link adds no value or violates venue rules, flag the article for revision or hold. Avoid sales-heavy CTAs, excessive self-links, affiliate links, UTM clutter, and disguised backlink campaigns.

## Style and structure

- Write in direct, professional English unless asked otherwise. Prefer concrete observations and instructions, moderate length, short headings, accurate terminology, and natural keywords. Avoid keyword repetition, unsupported “best,” “industry-leading,” “game-changing,” and fabricated exclusivity.
- SEO title, description, search intent, and headings should describe the article's real content. GEO means explicit, attributable answers and clear distinctions, not formulaic FAQ padding or artificial repetition.
- Few illustrations: use one simple process diagram, table, or annotated setup image only if it resolves a difficult concept. Secure permission and proper credit for images, diagrams, quotations, and customer stories.
- Rework the article for each venue: preserve the conclusion and evidence, change the angle and structure meaningfully. If an outlet accepts a properly attributed exact cross-post, use its supported route rather than making a token paraphrase.

## Example of cleaning

Weak: “Wind speed is essential to every vineyard. Our advanced station revolutionizes spraying with guaranteed precision.”

Better: “Before a vineyard spray pass, compare the wind observed at the block with the operation's own spray protocol and local requirements. A station can record on-site conditions, but sensor placement and the operator's decision rule determine whether the reading is useful.”

The example illustrates the reasoning pattern. Verify the relevant practice, regulation, sensor capability, and product fit before turning it into a published claim.
