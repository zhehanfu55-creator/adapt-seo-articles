# 使用前请提供

提交原创 SEO 文章时，请同时提供你希望在客座文章正文中展示的**自己的网站或落地页链接**。该链接是正文中的目标链接，与原文 URL、canonical 链接或作者简介链接不同。最好补充该页面与文章主题的关系，以及想投递的平台，例如 DigiKey TechForum、Medium、领英专栏文章或 IoT For All。

可直接使用：

> 请清洗这篇原创文章，并改写为适合 Medium 和 IoT For All 的文章。原文：[文章文本或 URL]。我希望正文中插入的落地页：[你的页面 URL]。如某个平台的投稿规则与该链接冲突，请标记出来。

本技能针对 Seeed Studio 的默认目标页：模组主题使用 https://www.seeedstudio.com/wio-module，专业气象站主题使用 https://www.seeedstudio.com/page/sensecap-professional-weather-station。**其他使用者必须提供自己的链接**，技能不会将这两个 Seeed 页面插入别人的文章。

链接会放在确实能帮助读者的段落里。如果链接与文章无关，或投稿平台不接受，技能会标记该平台稿件需要调整，而不会硬塞链接或声称已通过编辑审核。
